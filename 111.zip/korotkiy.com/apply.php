<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_name = $_POST['course_name'];
    $start_date = $_POST['start_date'];
    $payment_method = $_POST['payment_method'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO applications (user_id, course_name, start_date, payment_method) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $course_name, $start_date, $payment_method);
    if ($stmt->execute()) {
        $success = true;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Подать заявку</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Формирование заявки</h2>

        <?php if ($success): ?>
            <div style="color: green; text-align: center; margin-bottom: 1rem;">
                Заявка успешно отправлена!
            </div>
        <?php endif; ?>

        <form method="post">
            <select name="course_name" required>
                <option value="">Выберите курс</option>
                <option value="Основы алгоритмизации и программирования">Основы алгоритмизации и программирования</option>
                <option value="Основы веб-дизайна">Основы веб-дизайна</option>
                <option value="Основы проектирования баз данных">Основы проектирования баз данных</option>
            </select>

            <input type="date" name="start_date" required>

            <label><input type="radio" name="payment_method" value="Наличными" required> Наличными</label>
            <label><input type="radio" name="payment_method" value="Перевод на банковский счет"> Перевод на банковский счет</label>

            <button type="submit">Отправить заявку</button>
        </form>
    </div>
</body>
</html>