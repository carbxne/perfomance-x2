<?php
include 'db.php';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $login = $_POST['login'];
    $password = $_POST['password'];

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO users (fullname, email, phone, login, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $fullname, $email, $phone, $login, password_hash($password, PASSWORD_DEFAULT));
        $stmt->execute();
        header("Location: login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Регистрация</h2>
        <?php foreach ($errors as $error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endforeach; ?>
        <form method="post">
            <input type="text" name="fullname" placeholder="ФИО" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="phone" placeholder="+7(XXX)-XXX-XX-XX" required>
            <input type="text" name="login" placeholder="Логин" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <button type="submit">Зарегистрироваться</button>
        </form>
    </div>
</body>
</html>