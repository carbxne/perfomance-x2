<?php
session_start();

// Проверка логина администратора
if (!(isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true)) {
    header("Location: login.php");
    exit;
}

include '../db.php';
$applications = [];

$stmt = $conn->query("SELECT applications.*, users.fullname FROM applications JOIN users ON applications.user_id = users.id");

while ($row = $stmt->fetch_assoc()) {
    $applications[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'], $_POST['application_id'])) {
    $status = $_POST['status'];
    $id = $_POST['application_id'];

    $stmt = $conn->prepare("UPDATE applications SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель администратора</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <h2>Панель администратора</h2>
        <a href="logout.php" style="display: block; text-align: right; color: red; margin-bottom: 1rem;">Выйти</a>

        <table>
            <thead>
                <tr>
                    <th>Имя пользователя</th>
                    <th>Курс</th>
                    <th>Дата начала</th>
                    <th>Способ оплаты</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $app): ?>
                    <tr>
                        <td><?= htmlspecialchars($app['fullname']) ?></td>
                        <td><?= htmlspecialchars($app['course_name']) ?></td>
                        <td><?= $app['start_date'] ?></td>
                        <td><?= $app['payment_method'] ?></td>
                        <td><?= $app['status'] ?></td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                <select name="status" onchange="this.form.submit()">
                                    <option value="Новая" <?= $app['status'] === 'Новая' ? 'selected' : '' ?>>Новая</option>
                                    <option value="Идет обучение" <?= $app['status'] === 'Идет обучение' ? 'selected' : '' ?>>Идет обучение</option>
                                    <option value="Обучение завершено" <?= $app['status'] === 'Обучение завершено' ? 'selected' : '' ?>>Обучение завершено</option>
                                </select>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>