<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$applications = [];

$stmt = $conn->prepare("SELECT * FROM applications WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $applications[] = $row;
}

$review_success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_text'], $_POST['application_id'])) {
    $text = $_POST['review_text'];
    $app_id = $_POST['application_id'];

    $stmt = $conn->prepare("INSERT INTO reviews (application_id, text) VALUES (?, ?)");
    $stmt->bind_param("is", $app_id, $text);
    $stmt->execute();
    $review_success = true;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мои заявки</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Мои заявки</h2>

        <?php if ($review_success): ?>
            <div style="color: green; text-align: center; margin-bottom: 1rem;">
                Отзыв успешно добавлен!
            </div>
        <?php endif; ?>

        <?php if (empty($applications)): ?>
            <p>У вас еще нет заявок.</p>
        <?php else: ?>
            <?php foreach ($applications as $app): ?>
                <div style="border: 1px solid #ddd; padding: 1rem; margin-bottom: 1rem; border-radius: 6px;">
                    <strong><?= htmlspecialchars($app['course_name']) ?></strong><br>
                    Дата начала: <?= $app['start_date'] ?><br>
                    Способ оплаты: <?= $app['payment_method'] ?><br>
                    Статус: <?= $app['status'] ?><br>

                    <?php if ($app['status'] === 'Обучение завершено'): ?>
                        <form method="post" style="margin-top: 0.5rem;">
                            <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                            <textarea name="review_text" placeholder="Оставьте отзыв..." required></textarea>
                            <button type="submit">Отправить отзыв</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>