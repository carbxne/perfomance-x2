<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Короткий.com</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Добро пожаловать на Короткий.com</h1>
        <p style="text-align:center;">Запишитесь на онлайн-курсы дополнительного профессионального образования.</p>

        <nav>
            <a href="register.php">Регистрация</a>
            <a href="login.php">Вход</a>
            <a href="apply.php">Подать заявку</a>
            <a href="my-applications.php">Мои заявки</a>
            <a href="admin/login.php">Админка</a>
        </nav>
    </div>
</body>
</html>