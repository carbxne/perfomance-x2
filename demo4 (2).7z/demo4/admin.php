<?php
session_start();
require 'db.php';

if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_request']) && !empty($_POST['request_id'])) {
        $del_id = (int)$_POST['request_id'];
        $stmt = $pdo->prepare("DELETE FROM requests WHERE id = ?");
        $stmt->execute([$del_id]);
    } elseif (isset($_POST['update_request'], $_POST['request_id'], $_POST['status'])) {
        $request_id = (int)$_POST['request_id'];
        $status = $_POST['status'];
        $admin_comment = $_POST['admin_comment'] ?? '';
        $stmt = $pdo->prepare("UPDATE requests SET status = ?, admin_comment = ? WHERE id = ?");
        $stmt->execute([$status, $admin_comment, $request_id]);
    }
}

$stmt = $pdo->query("
    SELECT r.*, u.full_name
    FROM requests r
    JOIN users u ON r.user_id = u.id
    ORDER BY r.date_time DESC
");
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Админка</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<?php include 'header.php'; ?>

<h1>Панель администратора</h1>

<?php foreach ($requests as $r): ?>
    <section class="info-section" style="margin-bottom: 15px;">
        <p><strong>Пользователь:</strong> <?= htmlspecialchars($r['full_name']) ?></p>
        <p><strong>Тип услуги:</strong> <?= htmlspecialchars($r['service_type']) ?></p>
        <p><strong>Дата и время:</strong> <?= htmlspecialchars($r['date_time']) ?></p>
        <p><strong>Статус:</strong> 
            <span style="
                padding: 3px 10px; border-radius: 15px; color: white; font-weight: 600;
                background-color: <?= 
                    $r['status'] === 'новая' ? '#2980b9' : 
                    ($r['status'] === 'в работе' ? '#f39c12' : 
                    ($r['status'] === 'выполнено' ? '#27ae60' : 
                    ($r['status'] === 'отменено' ? '#c0392b' : '#7f8c8d')))
                ?>;
            ">
                <?= htmlspecialchars($r['status']) ?>
            </span>
        </p>
        <?php if ($r['admin_comment']): ?>
            <p><strong>Комментарий администратора:</strong> <?= htmlspecialchars($r['admin_comment']) ?></p>
        <?php endif; ?>

        <form method="post" style="margin-top:10px; display: flex; flex-wrap: wrap; gap: 10px; align-items: center;">
            <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
            
            <select name="status" style="width: 150px;">
                <?php
                $statuses = ['новая', 'в работе', 'выполнено', 'отменено'];
                foreach ($statuses as $s) {
                    $sel = ($r['status'] === $s) ? 'selected' : '';
                    echo "<option value=\"$s\" $sel>$s</option>";
                }
                ?>
            </select>
            
            <input type="text" name="admin_comment" value="<?= htmlspecialchars($r['admin_comment']) ?>" placeholder="Комментарий" style="flex-grow: 1; min-width: 200px;">
            
            <button type="submit" name="update_request" style="flex-shrink: 0;">Обновить</button>
            
            <button type="submit" name="delete_request" style="background-color: #c0392b; flex-shrink: 0;"
                onclick="return confirm('Удалить заявку?');">Удалить</button>
        </form>
    </section>
<?php endforeach; ?>

</body>
</html>
