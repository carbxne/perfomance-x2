<?php
if (session_status() == PHP_SESSION_NONE) session_start();
?>

<nav>
  <a href="index.php">Главная</a>

  <?php if (!empty($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
    <a href="admin.php">Админка</a>
    <a href="logout.php">Выйти</a>
  <?php elseif (!empty($_SESSION['user_id'])): ?>
    <a href="dashboard.php">Личный кабинет</a>
    <a href="logout.php">Выйти</a>
  <?php else: ?>
    <a href="login.php">Вход</a>
    <a href="register.php">Регистрация</a>
  <?php endif; ?>
</nav>
