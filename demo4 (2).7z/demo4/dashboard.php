<?php
session_start();
require 'auth.php';
require 'db.php';

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM requests WHERE user_id = ?");
$stmt->execute([$user_id]);
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Дашборд пользователя</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>

<header>
    <img src="logo.png" alt="Логотип" />
    <h1>Личный кабинет</h1>
</header>

<nav>
    <a href="index.php">Главная</a> <!-- Кнопка Главная -->
    <a href="dashboard.php">Мои заявки</a>
    <a href="new_request.php">Создать заявку</a>
    <a href="logout.php">Выйти</a>
</nav>

<main>
    <h2>Добро пожаловать, <?= htmlspecialchars($_SESSION['full_name']) ?></h2>

    <section class="info-section">
        <?php if (empty($requests)): ?>
            <p>У вас нет заявок.</p>
        <?php else: ?>
            <?php foreach ($requests as $r): ?>
                <div class="info-section" style="margin-bottom: 15px;">
                    <p><strong>Тип услуги:</strong> <?= htmlspecialchars($r['service_type']) ?></p>
                    <p><strong>Дата и время:</strong> <?= htmlspecialchars($r['date_time']) ?></p>
                    <p><strong>Статус:</strong> 
                        <span style="
                            padding: 3px 10px; border-radius: 15px; color: white; font-weight: 600;
                            background-color: <?= 
                                $r['status'] === 'новая' ? '#2980b9' : 
                                ($r['status'] === 'в работе' ? '#f39c12' : 
                                ($r['status'] === 'выполнено' ? '#27ae60' : 
                                ($r['status'] === 'отменено' ? '#c0392b' : '#7f8c8d')))
                            ?>;
                        ">
                            <?= htmlspecialchars($r['status']) ?>
                        </span>
                    </p>
                    <?php if ($r['status'] === 'отменено'): ?>
                        <p style="color:#c0392b;"><strong>Причина отмены:</strong> <?= htmlspecialchars($r['admin_comment']) ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</main>

<footer>
    © <?= date('Y') ?> Ваш сайт
</footer>

</body>
</html>
