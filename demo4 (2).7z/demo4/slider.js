document.addEventListener('DOMContentLoaded', () => {
    const slides = document.querySelectorAll('.slider .slide');
    let current = 0;
    const total = slides.length;

    function showSlide(index) {
        slides.forEach((slide, i) => {
            slide.classList.toggle('active', i === index);
        });
    }

    function nextSlide() {
        current = (current + 1) % total;
        showSlide(current);
    }

    // Показываем первый слайд
    showSlide(current);

    // Меняем слайд каждые 4 секунды
    setInterval(nextSlide, 4000);
});
