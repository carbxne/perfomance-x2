<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Мой Не Сам — Клининговые услуги</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>

<header>
    <img src="logo.png" alt="Логотип Мой Не Сам" />
    <h1>Мой Не Сам</h1>

    <?php include 'header.php'; ?>
</header>

<main>
    <section class="info-section">
        <h2>Добро пожаловать на портал клининговых услуг «Мой Не Сам»</h2>
        
        <div class="slider">
            <img src="slider1.jpg" alt="Уборка квартиры" class="slide active" />
            <img src="slider2.jpg" alt="Генеральная уборка" class="slide" />
            <img src="slider3.jpg" alt="Химчистка мебели" class="slide" />
        </div>
        
        <p>Мы помогаем вам легко и быстро заказывать профессиональную уборку жилых и производственных помещений. Наши услуги:</p>
        <ul>
            <li>Общий клининг</li>
            <li>Генеральная уборка</li>
            <li>Послестроительная уборка</li>
            <li>Химчистка ковров и мебели</li>
            <li>Иная услуга по вашему запросу</li>
        </ul>
    </section>

    <section class="info-section">
        <h2>Как это работает</h2>
        <ol>
            <li>Зарегистрируйтесь в системе, указав свои контактные данные.</li>
            <li>Войдите в личный кабинет.</li>
            <li>Создайте заявку, указав адрес, вид услуги, дату и время.</li>
            <li>Выберите удобный способ оплаты — наличными или картой.</li>
            <li>Ожидайте подтверждения заявки от администратора.</li>
        </ol>
    </section>

    <section class="info-section">
        <h2>Преимущества</h2>
        <p>Мы гарантируем качество, надежность и удобство:</p>
        <ul>
            <li>Профессиональные клинеры с опытом</li>
            <li>Гибкое расписание под ваш график</li>
            <li>Различные способы оплаты</li>
            <li>Поддержка клиентов 24/7</li>
        </ul>
    </section>

    <section style="text-align:center;">
        <?php if (!empty($_SESSION['user_id'])): ?>
            <p>Здравствуйте, <?=htmlspecialchars($_SESSION['username'] ?? 'Пользователь')?>! <a href="new_request.php">Создать новую заявку</a></p>
        <?php elseif (!empty($_SESSION['admin']) && $_SESSION['admin'] === true): ?>
            <p>Здравствуйте, администратор! <a href="admin.php">Перейти в админку</a></p>
        <?php endif; ?>
    </section>
</main>

<footer>
    &copy; <?=date('Y')?> Портал клининговых услуг «Мой Не Сам»
</footer>

<script src="slider.js"></script>
</body>
</html>
