<?php
session_start();
require 'auth.php';  // проверка авторизации
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $request_id = $_POST['request_id'] ?? null;
    $review_text = trim($_POST['review_text'] ?? '');

    if (!$request_id || empty($review_text)) {
        // Можно сделать редирект назад с ошибкой, но пока просто exit
        exit('Неверные данные.');
    }

    // Проверяем, что заявка принадлежит пользователю и статус "выполнено"
    $stmt = $pdo->prepare("SELECT * FROM requests WHERE id = ? AND user_id = ? AND status = 'выполнено'");
    $stmt->execute([$request_id, $user_id]);
    $request = $stmt->fetch();

    if (!$request) {
        exit('Нельзя оставить отзыв для этой заявки.');
    }

    // Вставляем отзыв
    $stmt = $pdo->prepare("INSERT INTO reviews (request_id, user_id, review_text) VALUES (?, ?, ?)");
    $stmt->execute([$request_id, $user_id, $review_text]);

    // Можно добавить сессию для flash-сообщения об успешной отправке
    $_SESSION['message'] = 'Отзыв успешно отправлен!';

    header('Location: dashboard.php');
    exit;
}
?>
