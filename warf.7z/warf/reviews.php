<?php
// Без session_start() и auth.php — страница открыта для всех
require 'db.php';

// Получаем все отзывы с информацией о заявке и пользователе
$sql = "
    SELECT r.review_text, r.created_at, u.full_name, req.service_type, req.date_time
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    JOIN requests req ON r.request_id = req.id
    ORDER BY r.created_at DESC
";
$stmt = $pdo->query($sql);
$reviews = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Отзывы пользователей</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>

<header>
    <img src="logo.png" alt="Логотип" />
    <h1>Отзывы пользователей</h1>
</header>

<nav>
    <a href="index.php">Главная</a> 
    <a href="dashboard.php">Мои заявки</a>
    <a href="new_request.php">Создать заявку</a>
    <a href="reviews.php">Отзывы</a>
    <a href="logout.php">Выйти</a>
</nav>

<main>
    <?php if (empty($reviews)): ?>
        <p>Пока нет отзывов.</p>
    <?php else: ?>
        <?php foreach ($reviews as $rev): ?>
            <div class="review" style="border: 1px solid #ddd; padding: 10px; margin-bottom: 15px; border-radius: 5px;">
                <p><strong>Пользователь:</strong> <?= htmlspecialchars($rev['full_name']) ?></p>
                <p><strong>Услуга:</strong> <?= htmlspecialchars($rev['service_type']) ?></p>
                <p><strong>Дата заявки:</strong> <?= htmlspecialchars($rev['date_time']) ?></p>
                <p><strong>Отзыв:</strong></p>
                <p style="background: #f9f9f9; padding: 10px; border-radius: 5px;"><?= nl2br(htmlspecialchars($rev['review_text'])) ?></p>
                <p style="font-size: 0.9em; color: #666;">Дата отзыва: <?= htmlspecialchars($rev['created_at']) ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</main>

<footer>
    © <?= date('Y') ?> Ваш сайт
</footer>

</body>
</html>
