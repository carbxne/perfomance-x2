<?php
session_start();
require 'auth.php';
require 'db.php';

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM requests WHERE user_id = ?");
$stmt->execute([$user_id]);
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мои заявки</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
    <h1>Здравствуйте, <?= htmlspecialchars($_SESSION['full_name']) ?></h1>
    <p><a href="new_request.php">Создать новую заявку</a> | <a href="logout.php">Выйти</a></p>
    <h2>История заявок</h2>
    <?php foreach ($requests as $r): ?>
        <div style="margin-bottom:10px; border-bottom:1px solid #ccc; padding-bottom:10px;">
            <strong>Услуга:</strong> <?= htmlspecialchars($r['service_type']) ?><br>
            <strong>Дата и время:</strong> <?= $r['date_time'] ?><br>
            <strong>Статус:</strong> <?= $r['status'] ?><br>
            <?php if ($r['status'] == 'отменено'): ?>
                <strong>Причина отмены:</strong> <?= htmlspecialchars($r['admin_comment']) ?><br>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>
</body>
</html>
