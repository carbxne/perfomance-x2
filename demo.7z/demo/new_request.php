<?php
session_start();
require 'auth.php';
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $datetime = $_POST['datetime'];
    $service = $_POST['service'];
    $custom = isset($_POST['custom_service']) ? $_POST['custom_service'] : null;
    $payment = $_POST['payment'];

    $stmt = $pdo->prepare("INSERT INTO requests (user_id, address, phone, service_type, custom_service, date_time, payment_type)
                           VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $address, $phone, $service, $custom, $datetime, $payment]);

    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Новая заявка</title>
    <link rel="stylesheet" href="styles.css">
    <script>
        function toggleCustom() {
            const check = document.getElementById('other');
            document.getElementById('custom_service').style.display = check.checked ? 'block' : 'none';
        }
    </script>
</head>
<body>
<div class="container">
    <h1>Создание заявки</h1>
    <form method="post">
        <input type="text" name="address" placeholder="Адрес" required>
        <input type="text" name="phone" placeholder="+7(XXX)-XXX-XX-XX" required>
        <input type="datetime-local" name="datetime" required>
        <select name="service" required onchange="toggleCustom()" id="service">
            <option value="общий клининг">Общий клининг</option>
            <option value="генеральная уборка">Генеральная уборка</option>
            <option value="послестроительная уборка">Послестроительная уборка</option>
            <option value="химчистка">Химчистка</option>
        </select>
        <label><input type="checkbox" id="other" onchange="toggleCustom()"> Иная услуга</label>
        <textarea name="custom_service" id="custom_service" placeholder="Опишите услугу" style="display:none;"></textarea>
        <select name="payment" required>
            <option value="наличные">Наличные</option>
            <option value="карта">Банковская карта</option>
        </select>
        <button type="submit">Отправить заявку</button>
    </form>
</div>
</body>
</html>
