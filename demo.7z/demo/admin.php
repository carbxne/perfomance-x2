<?php
session_start();
require 'db.php';

if (!isset($_SESSION['admin'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_request']) && !empty($_POST['delete_request_id'])) {
        $del_id = (int)$_POST['delete_request_id'];
        $stmt = $pdo->prepare("DELETE FROM requests WHERE id = ?");
        $stmt->execute([$del_id]);
    }
    if (isset($_POST['request_id'], $_POST['status'])) {
        $request_id = (int)$_POST['request_id'];
        $status = $_POST['status'];
        $admin_comment = $_POST['admin_comment'] ?? '';
        $stmt = $pdo->prepare("UPDATE requests SET status = ?, admin_comment = ? WHERE id = ?");
        $stmt->execute([$status, $admin_comment, $request_id]);
    }
}

$stmt = $pdo->query("
    SELECT r.*, u.full_name
    FROM requests r
    JOIN users u ON r.user_id = u.id
    ORDER BY r.date_time DESC
");
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Админка</title>
</head>
<body>
<h1>Панель администратора</h1>

<?php foreach ($requests as $r): ?>
    <div style="margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid #ccc;">
        <b><?=htmlspecialchars($r['full_name'])?></b><br>
        Статус: <?=$r['status']?><br>
        Комментарий: <?=htmlspecialchars($r['admin_comment'])?><br>

        <form method="post" style="margin:5px 0;">
            <input type="hidden" name="request_id" value="<?=$r['id']?>">
            <select name="status">
                <?php
                $statuses = ['новая', 'в работе', 'выполнено', 'отменено'];
                foreach ($statuses as $s) {
                    $sel = ($r['status']===$s) ? 'selected' : '';
                    echo "<option value=\"$s\" $sel>$s</option>";
                }
                ?>
            </select>
            <input type="text" name="admin_comment" value="<?=htmlspecialchars($r['admin_comment'])?>" placeholder="Комментарий" />
            <button type="submit">Обновить</button>
        </form>

        <form method="post" onsubmit="return confirm('Удалить заявку?');" style="margin:0;">
            <input type="hidden" name="delete_request_id" value="<?=$r['id']?>">
            <button type="submit" name="delete_request">Удалить</button>
        </form>
    </div>
<?php endforeach; ?>

</body>
</html>
